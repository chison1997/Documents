long long addmod(long long a, long long b, long long c);

long long multimod1(long long a, long long b, long long c);

long long mulmod(long long a, long long b, long long c);