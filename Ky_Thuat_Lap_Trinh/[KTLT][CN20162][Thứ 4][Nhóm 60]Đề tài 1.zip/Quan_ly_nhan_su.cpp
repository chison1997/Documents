#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<fstream>
#include<string>
#include<string.h>
#include<regex>
#include<time.h>
using namespace std;
//Cau truc chung

struct thoiGian
{
	int day;
	int month;
	int year;
	int gioDen;
	int phutDen;
	int gioVe;
	int phutVe;
	thoiGian *next;
	thoiGian *prev;
};
struct nhanVien
{
	string maNV;
	string hoDem;
	string ten;
	string donVi;
	string chucVu;
	string ngaySinh;
	string queQuan;
	string diaChi;
	string email;
	string soDienThoai;
	string ngayLamViecDauTien;
	thoiGian* thoiGianLamViec;
	nhanVien* next;	
	nhanVien* prev;
};
nhanVien *head = new nhanVien;

void printInfo(nhanVien* cur);

void init(nhanVien*&head)
{
	head->next = head;
	head->prev = head;
}
void init1(thoiGian*&head)
{
	head->next = head;
	head->prev = head;
}  
//cac ham them node
void addTime(thoiGian* p, thoiGian* head)
{ 
	thoiGian *cur;
	cur = head->next;
	p->next = cur;
	p->prev = cur->prev;
	cur->prev = p;
	(p->prev)->next = p;
}
void addnhanvien(nhanVien*p,nhanVien*head)
{ 
	nhanVien*cur;
	cur = head->next;
	p->next = cur;
	p->prev = cur->prev;
	cur->prev = p;
	(p->prev)->next = p;
}
void addsau(nhanVien*p,nhanVien*head)
{
	nhanVien *cur;
	cur = head->prev;
	p->prev = cur;
	p->next = cur->next;
	cur->next = p;
	(p->next)->prev = p;
}
 //cac ham in
void printTime(thoiGian *head)
{ 	
	thoiGian* cur;
	cur = head->prev;
	while(cur != head)
  	{	
  		if (cur->day >= 10) cout << cur->day << "/";
  		else cout << "0" << cur->day << "/";
  		
  		if (cur->month<=9) cout << "0" << cur->month << "/";
  		else cout << cur->month << "/";
  		
  		cout << cur->year << ",";
  		
  		if (cur->gioDen<=9) cout << "0" << cur->gioDen << ":";
  		else cout << cur->gioDen << ":";
  		
  		if (cur->phutDen >= 10) cout << cur->phutDen << ",";
  		else if(cur->phutDen != 0) cout << "0" << cur->phutDen << ",";
  		else cout << "00" << ",";
  		
  		if (cur->gioVe >= 10) cout << cur->gioVe << ":";
  		else cout << "0" << cur->gioVe << ":";
  		
  		if (cur->phutVe >= 10) cout << cur->phutVe << endl;
  		else if(cur->phutVe != 0) cout << "0" << cur->phutVe << endl;
  		else cout << "00" << endl; 
		cur = cur->prev;
	}  
}
void printNhanVien(nhanVien *head)
{
	nhanVien* cur;
	cur = head->prev;
	while(cur != head)
	{
		cout << cur->maNV << endl;
		cout << cur->hoDem << endl;
		cout << cur->ten << endl;
		cout << cur->donVi << endl;
		cout << cur->chucVu << endl;
		cout << cur->ngaySinh << endl;
		cout << cur->queQuan << endl;
		cout << cur->diaChi << endl;
		cout << cur->email << endl;
		cout << cur->soDienThoai << endl;
		cout << cur->ngayLamViecDauTien << endl;
		printTime(cur->thoiGianLamViec);
		cur = cur->prev;
	}
}      
void print1NhanVien(nhanVien *cur)
{
	printf("-----------------------------\n");
	thoiGian *k;
	k = cur->thoiGianLamViec;
	cout << cur->maNV << endl;
	cout << cur->hoDem << endl;
	cout << cur->ten << endl;
	cout << cur->donVi << endl;
	cout << cur->chucVu << endl;
	cout << cur->ngaySinh << endl;
	cout << cur->queQuan << endl;
	cout << cur->diaChi << endl;
	cout << cur->email << endl;
	cout << cur->soDienThoai << endl;
	cout << cur->ngayLamViecDauTien << endl;
	printTime(k);	
}
void printInfo(nhanVien* cur)
{
	cout << "Ma nhan vien: " << cur->maNV << endl;
	cout << "Ho va ten: " << cur->hoDem << " " << cur->ten << endl;
	cout << "Don vi: " << cur->donVi << endl;
	cout << "Chuc vu: " << cur->chucVu << endl;
	cout << "Ngay sinh: " << cur->ngaySinh << endl;
	cout << "Que quan: " << cur->queQuan << endl;
	cout << "Dia chi: " << cur->diaChi << endl;
	cout << "Email: " << cur->email << endl;
	cout << "So dien thoai: " << cur->soDienThoai << endl;
	cout << "Ngay lam viec dau tien: " << cur->ngayLamViecDauTien << endl;

}
//chuyen xau s ve chu hoa va chu so
string convert(string s)
{
	string result;
	for(int i = 0; i < s.size(); i++)
		if (isdigit(s[i]) || isalpha(s[i])) result.push_back(toupper(s[i]));
	return result;
}
// cac ham kiem tra
bool checkNgay(string s)
{
	regex pattern("(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[1,3-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})|(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))|(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$");
	if (regex_match(s, pattern))
		return 1;
	else return 0;	
}	
//kiem tra xau dang ngay, thang, nam, thoi gian den, thoi gian ve
bool check(string s)
{
	regex pattern("^(?:(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[1,3-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})|(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))|(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})),([0-9]|0[0-9]|1[0-9]|2[0-3]):([0-5][0-9]|[0-9]),([0-9]|0[0-9]|1[0-9]|2[0-3]):([0-5][0-9]|[0-9])$");
	if (regex_match(s, pattern))
		return 1;
	else return 0;	
}
// kiem tra email hop le
bool checkEmail(string s)
{
	regex pattern("[a-zA-Z0-9_\\.]+@[a-zA-Z]+\\.[a-zA-Z]+(\\.[a-zA-Z]+)*");
	if (regex_match(s, pattern))
		return 1;
	else return 0;
}
// kiem tra so dien thoai hop le
bool checkSDT(string s)
{
	regex pattern("(\\+84|0)\\d{9,10}");
	if (regex_match(s,pattern))
		return 1;
	else return 0;
}
//kiem tra xem co toan chu va dau cach
bool checkWord(string s)
{
	bool b = 1;
	for(int i = 0; i<s.length(); i++){
		if(( ! isalpha(s[i])) && (s[i] != ' '))
			b = 0; 
		if (b == 0) break;
	}
   return b;
}
bool check2String(string s1, string s2)
{
	string S;
	S = convert(s2);
	return s1.compare(S) == 0;
	 
}
//kiem tra xau s xem co the la maNV hay khong
bool checkMaNV(string s)
{
	if(s[0] !='N' || s[1] !='V') return 0;
	
	for(int i = 2; i < s.size(); i++)
		if( ! isdigit(s[i])) return 0; 

	return 1;
}
//cac ham xu li xau
//chuyen xau ve cau truc thoi gian
thoiGian* stringToTime(string s)
{
	thoiGian *t;
	t = new thoiGian;

	int p =	s.find('.');
	if(p == -1) 
		p = s.find('-');
	if(p == -1) 
		p = s.find('/');
	if(s[p-2] == '0'| s[p-2] == '1' | s[p-2] == '2' | s[p-2] == '3') 
		t->day = (s[0] - 48)*10 + (s[1] - 48);
	else t->day=(s[0] - 48);
	
	p = s.rfind('.');
	if(p == -1) 
		p = s.rfind('-');
	if(p == -1) 
		p = s.rfind('/');
	if (s[p-3] == '/'| s[p-3] == '-' | s[p-3] == '.') 
		t->month = (s[p-2] - 48)*10 + s[p-1] - 48;
	else t->month = s[p-1] - 48;
	
	t->year = (s[p+1] - 48)*1000 + (s[p+2] - 48)*100 + (s[p+3] - 48)*10 + s[p+4] - 48;
	
	p = s.find(':');
	if (s[p-3] == ',') 
		t->gioDen = (s[p-2] - 48)*10 + s[p-1] - 48;
	else t->gioDen = s[p-1] - 48;
	if (s[p+3] == ',') 
		t->phutDen = (s[p+1] - 48)*10 + s[p+2] - 48;
	else t->phutDen = s[p+1] - 48;

	p = s.rfind(':');
	if (s[p-3] == ',') 
		t->gioVe = (s[p-2] - 48)*10 + s[p-1] - 48;
	else t->gioVe = s[p-1] - 48;
	if ((s[p+2] != '\0')) 
		t->phutVe = (s[p+1] - 48)*10 + s[p+2] - 48; 
	else t->phutVe = s[p+1] - 48; 
	
	return t;
}
string Onlyword(string s)//tra ve xau toan chu
{
	string std;
	for(int i = 0; i<s.length(); i++) 
		if((s[i] >= 'a' && s[i]<='z')||(s[i] >= 'A' && s[i]<='Z')) std = std+s[i];
	return std;
}

//Ham chuyen doi ngay ve dang ngay/thang/nam 
string ngayChuan(string s)
{	
	int p = s.find('/');
	if (p == string::npos)
	{
		p = s.find('-');
		if (p != string::npos)
		{
			s = s.replace(p,1,"/");
		}
		else {
			p = s.find('.');
			s.replace(p,1,"/");
		}
		
		p = s.rfind('-');
		if (p != string::npos)
			s = s.replace(p,1,"/");
		else {
			p = s.rfind('.');
			s.replace(p,1,"/");
		}
	}
	return s;
}
//tra ve xau ko khoang trang
string  Nospace(string s)
{
	string std;
	for(int i = 0; i < s.length(); i++)
		if(s[i] != ' ') std = std+s[i];
	return std;
}
string vietHoa(string s)
{
	s[0] = toupper(s[0]);
	for (int i = 0; i < s.length(); i++)
	{
		if ((s[i]) == ' ') 
			s[i+1] = toupper(s[i+1]);
	}
	return s;
}

//cac ham xu li thoi gian
//so ngay trong thang
int numberDaysOfMonth(int thang, int nam)
{
	switch (thang)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 2:
			if (((nam%4 == 0) && (nam%100)) || (nam%400 == 0)) return 29;
			else return 28;
		default:
			return 30;
	}
}
//tong so thu bay, chu nhat cua thang
int weekend(int thang, int nam)
{
	int count, n, day;
	n = numberDaysOfMonth(thang, nam);
	if (thang < 3) 
	{
		thang += 12;
		nam ++;
	}
	day = (1 + 2*thang + (3 * (thang + 1)) / 5 + nam + (nam / 4) ) % 7; 
	for(int i = 1; i <= n; i++)
	{
		if (day % 6 == 0) count++;
		day ++;
		if (day == 7) day = 0;
	}
	return count;
}
//tong thoi gian den van phong trong ngay
inline float subTime(int h1, int m1, int h2, int m2)
{
	return (h2 - h1) + (m2 - m1) * 0.1 / 6;
}
//tim nhan vien co ma nhan vien la maNV
nhanVien* find(string maNV, nhanVien* head)
{
	nhanVien* p = head->next;
	while(p !=  head)
	{
		if (maNV.compare(p->maNV) == 0 ) return p;
		p = p->next;
	}
	return NULL;
}

//doc file
void readFile(nhanVien*head,int &count)
{
	string str;
    fstream f;
    f.open("data.txt",ios::in);
    if(f == 0)
	{
		cout << "file don't exit";
    	return;
    }
    else
	{
		getline(f,str);
    	while(!f.eof())
    	{   
			nhanVien *tiep;
        	tiep = new nhanVien;
        	tiep->thoiGianLamViec = new thoiGian;
        	init1(tiep->thoiGianLamViec);//khoi tao danh sach thoi gian
			tiep->maNV = str;
    		getline(f,tiep->hoDem);
    		getline(f,tiep->ten);
    		getline(f,tiep->donVi);
    		getline(f,tiep->chucVu);
    		getline(f,tiep->ngaySinh);
    		getline(f,tiep->queQuan);
    		getline(f,tiep->diaChi);
			getline(f,tiep->email);
			getline(f,tiep->soDienThoai);
			getline(f,tiep->ngayLamViecDauTien);
			getline(f,str);
			
			while(!(str[0] == 'N' && str[1] == 'V') && (!f.eof()))
		   {
		   		thoiGian *t;
		     	t = new thoiGian;
		     	t = stringToTime(str);
		 		addTime(t,tiep->thoiGianLamViec);
		    	getline(f,str);
		    }
		
			addnhanvien(tiep,head);
			count++;
		}
	}
	  f.close();
}
//chuc nang 1
void indanhsach(nhanVien *head,int count)
{
	nhanVien *ds1 = new nhanVien;
	nhanVien *ds2 = new nhanVien;
	nhanVien *ds3 = new nhanVien;
	nhanVien *ds4 = new nhanVien;
	init(ds1);
	init(ds2);
	init(ds3);
	init(ds4);
	nhanVien *cur;
	cur = head->next;
	clock_t start = clock();
	while(cur != head)
	{ 
		string str;
		nhanVien*em;
		em = new nhanVien;
		em->chucVu = cur->chucVu;
		em->diaChi = cur->diaChi;
		em->donVi = cur->donVi;
		em->email = cur->email;
		em->hoDem = cur->hoDem;
		em->maNV = cur->maNV;
		em->ngayLamViecDauTien = cur->ngayLamViecDauTien;
		em->ngaySinh = cur->ngaySinh;
		em->queQuan = cur->queQuan;
		em->soDienThoai = cur->soDienThoai;
		em->ten = cur->ten;
		em->thoiGianLamViec = cur->thoiGianLamViec;
		str = em->chucVu;
		std::transform(str.begin(),str.end(),str.begin(),::tolower);
		str = Nospace(str);
		if(str == "chutich") addsau(em,ds1);
		else if(str == "phochutich") addnhanvien(em,ds1);
		else if(str == "giamdoc") addsau(em,ds2);
		else if(str == "phogiamdoc") addnhanvien(em,ds2);
		else if(str == "truongphong") addsau(em,ds3);
		else if(str == "phophong") addnhanvien(em,ds3);
		else addsau(em,ds4); 
		cur = cur->next;
    }
	cout << "BK Corporations" << endl;
	nhanVien*sau;
	sau = ds1->prev;
	while(sau != ds1)
	{
		cout << sau->chucVu << ": " << sau->hoDem << " " << sau->ten << endl;
		sau = sau->prev;
	}
	cout << endl;
	sau = ds2->prev;
	while(sau != ds2)
    {
		nhanVien*truoc;
		truoc = ds2->next;
		string t1,t2;
		t1 = sau->chucVu;
		t2 = sau->donVi;
		std::transform(t1.begin(),t1.end(),t1.begin(),::tolower);
		t1 = Nospace(t1);
		std::transform(t2.begin(),t2.end(),t2.begin(),::tolower);
		t2 = Onlyword(t2);
		if(t1 == "giamdoc") 
		{      
			cout << "cong ty:  " << sau->donVi << endl;
			cout << "giam doc: " << sau->hoDem << " " << sau->ten << endl;
			nhanVien*truoc;
			truoc = ds2->next;
			while(truoc != ds2)  
			{
				string t3,t4;
				t3 = truoc->donVi;
				t4 = truoc->chucVu;
				std::transform(t3.begin(),t3.end(),t3.begin(),::tolower);
				t3 = Onlyword(t3);
				std::transform(t4.begin(),t4.end(),t4.begin(),::tolower);
				t4 = Nospace(t4);
				if((t3 == t2) && (t4 == "phogiamdoc")) cout << "pho giam doc: " << truoc->hoDem << " " << truoc->ten << endl;
				truoc = truoc->next;
			} 
			cout << endl; 
		}

		sau = sau->prev;
	}
	sau = ds3->prev;
	while(sau != ds3)
    {
		nhanVien*truoc;
	    truoc = ds3->next;
	    string s1,s2;
	    s1 = sau->chucVu;
	    s2 = sau->donVi;
	    std::transform(s1.begin(),s1.end(),s1.begin(),::tolower);
	    s1 = Nospace(s1);
	    std::transform(s2.begin(),s2.end(),s2.begin(),::tolower);
	    s2 = Onlyword(s2);
	    if(s1 == "truongphong") 
		{      
			cout << "phong:   " << sau->donVi << endl;
			cout << "truong phong: " << sau->hoDem << " " << sau->ten << endl;
			nhanVien*truoc;
			truoc = ds3->next;
			while(truoc != ds3)  
			{
				string s3,s4;
				s3 = truoc->donVi;
				s4 = truoc->chucVu;
				std::transform(s3.begin(),s3.end(),s3.begin(),::tolower);
				s3 = Onlyword(s3);
				std::transform(s4.begin(),s4.end(),s4.begin(),::tolower);
				s4 = Nospace(s4);
				if((s3 == s2) && (s4 == "phophong"))
					cout << "pho phong: " << truoc->hoDem << " " << truoc->ten << " " << endl;
				truoc = truoc->next;
			}  
			cout << endl;
		}
		sau = sau->prev;
	}
	cout << "Tong so nhan vien: " << count << endl;
	cout << endl;
	
	printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
}


//chuc nang 2
void timKiem(nhanVien *head)
{	
	nhanVien *cur;
	cur = head->next;
	string t;
	int a;
	if (system("CLS")) system("clear");

	printf("\n----------------TIM KIEM NHAN VIEN-----------------\n");
	cout << "Ban muon tim theo thong tin nao:" << endl;
	cout << "Phim so 1: Ma nhan vien" << endl;
	cout << "Phim so 2: Ho dem" << endl;
	cout << "Phim so 3: Ten" << endl;
	cout << "Phim so 4: Ho va ten" << endl;
	cout << "Phim so 5: Email" << endl;
	cout << "Phim so 6: So dien thoai" << endl;
	cin >> a;
	switch(a)
	{
		case 1: 
		{
			cout << "Nhap ma nhan vien:" << endl;
			string maNV;
			nhanVien* NV = NULL;
			cin.ignore();
			do
			{
				printf("\nMa nhan vien: ");
				getline(cin, maNV);
				clock_t start = clock();
				maNV = convert(maNV);
				if (checkMaNV(maNV)) NV = find(maNV, head);
				if (NV != NULL) break;
				else  printf("\nMa nhan vien khong ton tai, moi ban nhap lai: \n");
				 printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
			} while(1);
			cout << "---------------------------------------------" << endl;
			printInfo(NV); 
			break;
			
		}
		case 2: 
		{	
			int dem = 0;
			cout << "Nhap ho dem:" << endl;
			cin.ignore();
			getline(cin,t);
			t = Nospace(t);
			std::transform(t.begin(),t.end(),t.begin(),::tolower);
			clock_t start = clock();
			while(cur != head)
			{
				string t0 = cur->hoDem;
				t0 = Nospace(t0);
				std::transform(t0.begin(),t0.end(),t0.begin(),::tolower);
				int tim = t0.find(t);
				if(tim != string::npos){
					dem++;
					cout << "---------------------------------------------" << endl;
					printInfo(cur); 
				}
				cur = cur->next; 
			} 
			if(dem == 0) cout << "khong ton tai nhan vien co ho dem can tim" << endl;
			  printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
						break;
		}	
		case 3: 
		{	
			int dem = 0;
			cout << "Nhap ten:" << endl;
			cin.ignore();
			getline(cin,t);
			std::transform(t.begin(),t.end(),t.begin(),::tolower);
				clock_t start = clock();
			while(cur != head)
			{
				string t0 = cur->ten;
				std::transform(t0.begin(),t0.end(),t0.begin(),::tolower);
				int tim = t0.find(t);
				if(tim != string::npos){
					dem++;
					cout << "---------------------------------------------" << endl;
					printInfo(cur); 
				}
				cur = cur->next; 
			} 
			if(dem == 0) cout << "khong ton tai nhan vien co ten can tim" << endl;
			printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
			break;
		}	
		case 4: 
		{	
			int dem = 0;
			string tt;
			cout << "Nhap ho dem:" << endl;
			cin.ignore();
			getline(cin,t);
			cout << "Nhap ten:" << endl;
			getline(cin,tt);
			t = t+tt;
			t = Nospace(t);
			std::transform(t.begin(),t.end(),t.begin(),::tolower);
				clock_t start = clock();
			while(cur != head)
			{
				string t0 = cur->hoDem + cur->ten;
				t0 = Nospace(t0);
				std::transform(t0.begin(),t0.end(),t0.begin(),::tolower);
				int tim = t0.find(t);
				if(tim != string::npos){
					dem++;
					cout << "---------------------------------------------" << endl;
					printInfo(cur); 
				}
				cur = cur->next; 
			} 
			if(dem == 0) cout << "khong ton tai nhan vien " << endl;
			printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
			break;
		}
		case 5: 
		{
			int dem = 0;
			cout << "Nhap Email:" << endl;
			cin.ignore();
			getline(cin,t);
			while( ! checkEmail(t)){
				cout << "Dia chi email khong hop le. Ban vui long nhap lai:" << endl;
				getline(cin,t);
			}
			clock_t start = clock();
			while(cur != head)
			{
				string t0 = cur->email;
				int tim = t0.find(t);
				if(tim != string::npos){
					dem++;
					cout << "---------------------------------------------" << endl;
					printInfo(cur); 
				}
				cur = cur->next; 
			} 
			if(dem == 0) cout << "khong ton tai nhan vien " << endl;
			printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
			break;
		}
		case 6: 
		{	
			int dem = 0;
			cout << "Nhap so dien thoai:" << endl;
			cin.ignore();
			getline(cin,t);
			while( ! checkSDT(t)){
				cout << "So dien thoai khong hop le. Ban vui long nhap lai:" << endl;
				getline(cin,t);
			}
			clock_t start = clock();
			while(cur != head)
			{
				string t0 = cur->soDienThoai;
				int tim = t0.find(t);
				if(tim != string::npos){
					dem++;
					cout << "---------------------------------------------" << endl;
					printInfo(cur); 
				}
				cur = cur->next; 
			} 
			if(dem == 0) cout << "khong ton tai nhan vien " << endl;
			printf("Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
			break;
		}
		
	 }
	getch();
	if (system("CLS")) system("clear");
}

//chuc nang 3
//thong tin lam viec cua nhan vien co "maNV" vao thang, nam nhap tu ban phim
void chucNang3(nhanVien* head)
{
	
	char buffer[50];
	int thang, nam, soNgayNghi, workDate = 0, missDate = 0, beginHour, beginMinus, endHour, endMinus;
	float missHour;
	nhanVien* NV = NULL;
	
	if (system("CLS")) system("clear");
	printf("\n-------------THONG TIN LAM VIEC CUA NHAN VIEN-----------------\n");
	
	string maNV;
	cin.ignore();
	do
	{
		printf("\nMa nhan vien: "); getline(cin, maNV);
		maNV = convert(maNV);
		if (checkMaNV(maNV)) NV = find(maNV, head);
		if (NV != NULL) break;
		else  printf("\nMa nhan vien khong ton tai, moi ban nhap lai: \n");
	} while(1);

	thoiGian* t = NV -> thoiGianLamViec;
	thoiGian* p = t->next;

	do
	{
		printf("\nThang can truy van: "); gets(buffer);
		thang = atoi(buffer);
	} while ((thang < 1) || (thang >12));
	
	do
	{
		printf("\nNam can truy van: "); gets(buffer);
		nam = atoi(buffer);
	} while (nam < 1990 || nam > 2017);
	
	printf("\nThoi diem bat dau gio lam viec:");
	
	do
	{
		printf("\nGio: "); gets(buffer);
		beginHour = atoi(buffer);
	} while (beginHour <= 0 || beginHour >23);
	
	do
	{
		printf("\nPhut: "); gets(buffer);
		beginMinus = atoi(buffer);
	} while (beginMinus <= 0 || beginMinus >= 60);
	
		printf("\nThoi diem ket thuc gio lam viec:");
	
	do
	{
		printf("\nGio: "); gets(buffer);
		endHour = atoi(buffer);
	} while (endHour <= 0 || endHour >23);
	
	do
	{
		printf("\nPhut: "); gets(buffer);
		endMinus = atoi(buffer);
	} while (endMinus <= 0 || endMinus >= 60);
	
	do
	{
		printf("\nSo ngay nghi bat thuong trong thang cua cong ty (nghi Tet, nghi mat, nghi do thien tai...): ");
		scanf("%d", &soNgayNghi);
	} while (soNgayNghi < 0 || soNgayNghi > numberDaysOfMonth(thang, nam) );
	
	printf("\n-------------------------------------------------\n");
	clock_t start = clock();
	while (p !=  t )
	{
		if (p->year < nam) break;
		if (p->year == nam)
		{
			if(p->month == thang)
			{
				workDate ++;
				float temp = subTime(p->gioDen, p->phutDen, beginHour, beginMinus);
				if (temp > 0) missHour += temp;
				temp = subTime(endHour, endMinus, p->gioVe, p->phutVe);
				if (temp > 0) missHour += temp;
			}
			else if (p->month < thang) break;
		}
		p = p->next;
	}
	
	missDate = numberDaysOfMonth(thang, nam) - workDate - weekend(thang, nam) - soNgayNghi; 
	
	if (system("CLS")) system("clear");
	printf("\n-------------THONG TIN LAM VIEC CUA NHAN VIEN-----------------\n");
	
	printInfo(NV);
	printf("So ngay lam viec trong thang %d: %d\n", thang, workDate);
	if (missDate > 0) printf("So ngay nghi viec trong thang: %d\n", missDate);
	else printf("Nhan vien khong nghi viec trong thang.\n");
	if (missHour > 0)
		printf("So gio di muon, ve som: %.0f", missHour);
	else if (missHour == 0) 
		printf("Nhan vien di, ve dung gio.\n");
	
	printf("\n Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
	
	getch();
	if (system("CLS")) system("clear");
	
}
//chuc nang 4
//in cac nhan vien cua mot don vi
void printDonVi(nhanVien* head)
{
	if (system("CLS")) system("clear");
	printf("--------------THONG TIN NHAN SU CUA DON VI----------------\n");
	string tenDonViConvert, tenDonVi;
	int count = 0;
	cin.ignore();
	do
	{
		printf("\nTen don vi: "); getline(cin, tenDonVi);
		tenDonViConvert = convert(tenDonVi);
		nhanVien* p = head->next;
		clock_t start = clock();
		while(p != head)
		{
			if(check2String(tenDonViConvert, p->donVi)) 
			{
				if (count == 0) 
				{
					if (system("CLS")) system("clear");
					printf("--------------%s----------------\n\n", p->donVi.c_str());
				}
				printInfo(p);
				printf("\n-----------------------------------\n");
				count++;
			}
			p = p->next;
		}
		if (count == 0) printf("Khong ton tai don vi %s\n", tenDonVi.c_str());
		else printf("Tong so: %d nhan vien\n", count);
		printf("\n Time: %.2fs\n", (double)(clock() - start)/CLOCKS_PER_SEC);
	} while (count == 0);
	getch();
	if (system("CLS")) system("clear");
}

//chuc nang 5
void themNhanVien(int &count)
{
	int n;
	if (system("CLS")) system("clear");
	printf("\n-------------THEM NHAN VIEN-----------------\n");
	cout << "Ban can them bao nhieu nhan vien: ";
	cin >> n;
	
	string str;  
	nhanVien *tiep;
	tiep = new nhanVien;
	tiep->thoiGianLamViec = new thoiGian;
	init1(tiep->thoiGianLamViec);
	fstream f;
	f.open("data.txt", ios::out | ios::app);
	for (int i = 1; i <= n; i++){
		count++;
		cout << "Moi ban nhap cac thong tin cua nhan vien:";
		
		cout << "\nHo dem: ";
		cin.ignore();
		getline(cin,str);
		tiep->hoDem = vietHoa(str);
		
		cout << "\nTen: ";
		getline(cin,str);
		str[0] = toupper(str[0]);
		tiep->ten = str;
		
		cout << "\nDon vi: ";
		getline(cin,str);
		str[0] = toupper(str[0]);
		tiep->donVi = str;
		
		cout << "\nChuc vu: ";
		getline(cin,str);
		str[0] = toupper(str[0]);
		tiep->chucVu = str;
		
		cout << "\nNgay sinh: ";
		getline(cin,str);
		while ( ! checkNgay(str))
		{
			cout << "\nVui long nhap lai ngay sinh: ";
			getline(cin,str);
		}
		str = ngayChuan(str);
		tiep->ngaySinh = str;	
		
		cout << "\nQue quan: ";
		getline(cin,str);
		tiep->queQuan = vietHoa(str);
		
		cout << "\nDia chi: ";
		getline(cin,str);
		tiep->diaChi = vietHoa(str);
		
		cout << "\nEmail: ";
		getline(cin,str);
		while( ! checkEmail(str))
		{
			cout << "\nVui long nhap lai Email: ";
			getline(cin,str);
		}
		tiep->email = str;
	
		cout << "\nSo dien thoai: ";
		getline(cin,str);
		while( ! checkSDT(str))
		{
			cout << "\nVui long nhap lai So dien thoai: ";
			getline(cin,str);
		}
		tiep->soDienThoai = str;
		
		cout << "\nNgay lam viec dau tien: ";
		getline(cin,str);
		while ( ! checkNgay(str))
		{
			cout << "\nVui long nhap lai ngay lam viec dau tien: ";
			getline(cin,str);
		}
		str = ngayChuan(str);
		tiep->ngayLamViecDauTien = str;
		
		f << "\nNV" << count << endl;
		f << tiep->hoDem << endl;
		f << tiep->ten << endl;
		f << tiep->donVi << endl;
		f << tiep->chucVu << endl;
		f << tiep->ngaySinh << endl;
		f << tiep->diaChi << endl;
		f << tiep->queQuan << endl;
		f << tiep->email << endl;
		f << tiep->soDienThoai << endl;
		f << tiep->ngayLamViecDauTien << endl;
		
		cout << "\nNgay lam viec,Thoi gian den,Thoi gian ve:\n";
		
		while(1)
		{
			getline(cin,str);
			if (str.empty()) break;
			str = Nospace(str);
			while( ! check(str))
			{
				cout << "\nVui long nhap lai:";
				getline(cin,str);
			}
			thoiGian *t1,*t;
			t1 = new thoiGian;
			t1 = stringToTime(str);
			addTime(t1,tiep->thoiGianLamViec); 
			t = tiep->thoiGianLamViec->next;
			
			if (t->day >= 10) 
				f << t->day << "/";
	  		else f << "0" << t->day << "/";
	  		
	  		if (t->month<=9) 
				f << "0" << t->month << "/";
	  		else f << t->month << "/";
	  		
	  		f << t->year << ",";
	  		f << t->gioDen << ":";
	  		
	  		if (t->phutDen >= 10) 
				f << t->phutDen << ",";
	  		else if(t->phutDen != 0) 
				f << "0" << t->phutDen << ",";
	  			else f << "00" << ",";
	  			
	  		f << t->gioVe << ":";
	  		
	  		if (t->phutVe >= 10)
				f << t->phutVe;
	  		else if(t->phutVe != 0) 
			  	f << "0" << t->phutVe;
	  			else f << "00";
	
		}
		
		addnhanvien(tiep,head);
		
	}
	cout << "Ban da hoan thanh xong them nhan vien!" << endl;
	f.close();
	getch();
	if (system("CLS")) system("clear");
}

//chuc nang 6
void updateNhanVien(nhanVien *head,nhanVien *&cur)
{    
	int m;
	string temp;
	do
	{
		cout << "--------------Ban muon cap nhat noi dung gi:------------" << endl;
		cout << "Phim 1: Ho ten" << endl;
		cout << "Phim 2: Ma nhan vien" << endl;
		cout << "Phim 3: Don vi va Chuc vu" << endl;
		cout << "Phim 4: Ngay sinh" << endl;
		cout << "Phim 5: Que quan va Dia chi" << endl;
		cout << "Phim 6: Ngay lam viec dau tien" << endl;
		cout << "Phim 7: Email va So dien thoai" << endl;
		cout << "Phim 0: Thoat" << endl;
		cin >> m;
		switch(m)
	    {
	     	case 1:
			{      
				string t1,t2; 
				cout << "Nhap hoDem" << endl; 
				cin.ignore();
				getline(cin,t1); 
				while( ! checkWord(t1))
				{
					cout << "nhap lai ho dem" << endl;
					getline(cin,t1);
				}
				t1 = vietHoa(t1);
				cur->hoDem = t1;               
				cout << "Nhap ten" << endl;
				getline(cin,t2);
				while( ! checkWord(t2))
				{
					cout << "nhap lai ho dem" << endl;
					getline(cin,t2);
				}
				t2 = vietHoa(t2);
				cur->ten = t2;                          
				cout << "Cap nhat xong!" << endl;
				break;
	        }
			case 2:
			{ 
				string t1;
				cout << "Nhap maNV" << endl;
				cin.ignore();
				getline(cin,t1);
				t1 = Nospace(t1);
				std::transform(t1.begin(), t1.end(),t1.begin(), ::toupper);
				while( ! checkMaNV)
				{
					cout << "nhap lai maNV" << endl;
					getline(cin,t1);
					t1 = Nospace(t1);
					std::transform(t1.begin(), t1.end(),t1.begin(), ::toupper);
				}
				cur->maNV = t1;
				cout << "Cap nhat xong!" << endl;
				break;	
		    }
	   		case 3:
		    { 
				string t1,t2;
				cout << "Nhap ten don vi" << endl;
				cin.ignore();
				getline(cin,t1);
				t1[0] = toupper(t1[0]);
				cur->donVi = t1;
				
				cout << "Nhap chuc vu" << endl;
				cin.ignore();
				getline(cin,t2);
				t2[0] = toupper(t2[0]);
				cur->chucVu = t2;
				
				cout << "Cap nhat xong!" << endl;
				break;
	        }
	   		case 4:
			{ 	
				string t1;
				cout << "Nhap ngay sinh" << endl;
				getline(cin,t1);
				while( ! checkNgay(t1))
			    {
					cout << "Nhap lai ngay sinh:" << endl;
					getline(cin,t1); 
				}
				t1 = ngayChuan(t1);
				cur->ngaySinh = t1;
				cout << "Cap nhat xong!" << endl;
				break;
			}
	   		case 5:
			{ 
				string t1,t2;
				cout << "Nhap que quan" << endl;
				cin.ignore();
				getline(cin,t1);
				t1 = vietHoa(t1);
				cur->queQuan=t1;
				cout << "Nhap dia chi" << endl;
				cin.ignore();
				getline(cin,t2);
				cur->diaChi = t2;
				cout << "Cap nhat xong!" << endl;
				break;
			}
	   		case 6:
			{
				string t1;
				cout << "Nhap ngay lam viec dau tien" << endl;
				getline(cin,t1);
				while( ! checkNgay(t1))
				{
					cout << "Nhap lai ngay lam viec dau tien:" << endl;
					getline(cin,t1); 
				}
				t1 = ngayChuan(t1);
				cur->ngayLamViecDauTien = t1;
				cout << "Cap nhat xong!" << endl;
				break;
			}
	   		case 7:
			{  
				string t1,t2;
				regex tiep("[a-zA-Z0-9_\\.]+@[a-zA-Z]+\\.[a-zA-Z]+(\\.[a-zA-Z]+)*");
				cout << "Nhap email" << endl;
				cin.ignore();
				getline(cin,t1);
				while(regex_match(t1,tiep) != 1)
				{
					cout << "Nhap lai email theo dang abcxyz@gmail.com" << endl;
					getline(cin,t1);
				}
				cur->email = t1;
				regex tiep1("(\\+84|0)\\d{9,10}");
				cout << "Nhap so dien thoai" << endl;
				getline(cin ,t2);
				while(regex_match(t2,tiep1) != 1)
				{
					cout << "Nhap lai so dien thoai co 10 hay 11 so" << endl;
					getline(cin,t2);
				}
				cur->soDienThoai = t2;
				cout << "Cap nhat xong!" << endl;
				break;
			}				
			case 0:
	        	break; 
		    	
        }
    }while(m != 0);
	fstream f;
	f.open("data.txt", ios::out);
	nhanVien *tiep;
	tiep = head->prev;
	while(tiep != head)
	{
		f << tiep->maNV << endl;
		f << tiep->hoDem << endl;
		f << tiep->ten << endl;
		f << tiep->donVi << endl;
		f << tiep->chucVu << endl;
		f << tiep->ngaySinh << endl;
		f << tiep->diaChi << endl;
		f << tiep->email << endl;
		f << tiep->soDienThoai << endl;
		f << tiep->ngayLamViecDauTien << endl;
		thoiGian *t;
		t = tiep->thoiGianLamViec->prev;
		while(t != (tiep->thoiGianLamViec))
        {
        	f << t->day << "/" << t->month << "/" << t->year << "," << t->gioDen << ":" << t->phutDen << "," << t->gioVe << ":" << t->phutVe << endl;		 
			t = t->prev;
		}		
	    tiep = tiep->prev;
    }
	cout << "Cap nhat xong!" << endl;
}

int main()
{
	int count = 0;
	int a;
	init(head);
	readFile(head,count);
 	do
	{
		cout << endl << "---------------------TUY CHON-------------------------------" << endl;
		cout << "Nhap vao so 1 : Thong tin co ban  BKCorporation " << endl;
		cout << "Nhap vao so 2 : Tim kiem thong tin cua nhan vien" << endl;
		cout << "Nhap vao so 3 : Tinh trang cua nhan vien" << endl;
		cout << "Nhap vao so 4 : Hien thi thong tin 1 don vi" << endl;
		cout << "Nhap vao so 5 : Them nhan vien" << endl;
		cout << "Nhap vao so 6 : Cap nhat thong tin co ban cua nhan vien" << endl;
		cout << "Nhap vao so 0 : Thoat" << endl;
		cout << "Nhap phim so: " << endl; 
		cin >> a;
		switch (a)
		{
			case 0:
				break;
			case 1:
			{
			    indanhsach(head,count);
			 	break;
			}
			case 2:
			{
				timKiem(head);
				break;
			}
			case 3:
			{
				chucNang3(head);
				break;
			}
			case 4:
		    {
				printDonVi(head);
				break;
			}
			case 5:
		    {
				themNhanVien(count);	
				break;
			}
			case 6:
			{	
				timKiem(head);
		        nhanVien* tiep;
		        string std;
		        do
               	{
		            printf("\nMa nhan vien: ");
					getline(cin, std);
			        std = convert(std);
			        if (checkMaNV(std)) tiep = find(std,head);
		         	if (tiep != NULL) break;
		         	else  printf("\nMa nhan vien khong ton tai, moi ban nhap lai: \n");
            	} while(1);
		        printInfo(tiep);
		        updateNhanVien(head,tiep);
		     	break;
		    }
		}
			 
	} while(a != 0);
	

	return 0;
}
