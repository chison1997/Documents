// VD10_EventSelect.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "winsock2.h"

int main()
{
	SOCKET sockets[WSA_MAXIMUM_WAIT_EVENTS];
	WSAEVENT events[WSA_MAXIMUM_WAIT_EVENTS];
	int totalEvents = 0;

	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);

	SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(9000);

	bind(listener, (SOCKADDR *)&addr, sizeof(addr));
	listen(listener, 5);

	WSAEVENT newEvent = WSACreateEvent();
	WSAEventSelect(listener, newEvent, FD_ACCEPT);

	sockets[totalEvents] = listener;
	events[totalEvents] = newEvent;
	totalEvents++;

	WSANETWORKEVENTS networkEvents;

	while (true)
	{
		int index = WSAWaitForMultipleEvents(totalEvents, events, FALSE, 5000, FALSE);
		if (index == WSA_WAIT_FAILED)
			break;
		if (index == WSA_WAIT_TIMEOUT)
		{
			printf("Timed out.\n");
			continue;
		}

		index = index - WSA_WAIT_EVENT_0;
		for (int i = index; i < totalEvents; i++)
		{
			index = WSAWaitForMultipleEvents(1, &events[i], FALSE, WSA_INFINITE, FALSE);
			if (index == WSA_WAIT_FAILED)
				continue;
			if (index == WSA_WAIT_TIMEOUT)
			{
				printf("Timed out.\n");
				continue;
			}

			WSAEnumNetworkEvents(sockets[i], events[i], &networkEvents);
			if (networkEvents.lNetworkEvents & FD_ACCEPT)
			{
				if (networkEvents.iErrorCode[FD_ACCEPT_BIT] != 0)
					continue;

				SOCKET client = accept(sockets[i], NULL, NULL);
				
				if (totalEvents > WSA_MAXIMUM_WAIT_EVENTS)
				{
					printf("Too many events.\n");
					closesocket(client);
					continue;
				}

				newEvent = WSACreateEvent();
				WSAEventSelect(client, newEvent, FD_READ);

				sockets[totalEvents] = client;
				events[totalEvents] = newEvent;
				totalEvents++;

				printf("New client accepted: %d", client);
			}

			if (networkEvents.lNetworkEvents & FD_READ)
			{
				if (networkEvents.iErrorCode[FD_READ_BIT] != 0)
					continue;

				char buf[1024];
				int res = recv(sockets[i], buf, sizeof(buf), 0);
				if (res == SOCKET_ERROR || res == 0)
					continue;
				
				buf[res] = 0;
				printf("%s", buf);
			}
		}

	}

	closesocket(listener);
	WSACleanup();
    return 0;
}

