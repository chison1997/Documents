// Server3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "winsock2.h"

void removeSocket(SOCKET *clients, int *pNumClients, SOCKET removedClient)
{
	int i = 0;
	for (; i < *pNumClients; i++)
		if (clients[i] == removedClient)
			break;
	if (i < *pNumClients - 1)
		clients[i] = clients[*pNumClients - 1];
	*pNumClients = *pNumClients - 1;
}

int main()
{
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);

	SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(9000);

	bind(listener, (SOCKADDR *)&addr, sizeof(addr));
	listen(listener, 5);

	fd_set fdread;
	int res;
	SOCKET clients[64];
	int numClients = 0;

	char buf[1024], filebuf[1024];
	char cmd[16], path[64];


	while (true)
	{
		FD_ZERO(&fdread);
		FD_SET(listener, &fdread);
		for (int i = 0; i < numClients; i++)
			FD_SET(clients[i], &fdread);

		res = select(0, &fdread, NULL, NULL, NULL);
		if (res == SOCKET_ERROR)
			break;
		if (res > 0)
		{
			if (FD_ISSET(listener, &fdread))
			{
				SOCKET client = accept(listener, NULL, NULL);
				clients[numClients] = client;
				numClients++;
			}
			for (int i = 0; i < numClients; i++)
				if (FD_ISSET(clients[i], &fdread))
				{
					// Xu ly du lieu nhan duoc tu client
					res = recv(clients[i], buf, sizeof(buf), 0);
					if (res == SOCKET_ERROR || res == 0)
					{
						continue;
					}
						
					buf[res] = 0;
					printf("%s", buf);

					res = sscanf(buf, "%s %s", cmd, path);
					if (res == 2)
					{
						if (strcmp(path, "/") == 0)
						{
							// yeu cau thu muc goc, gui xau Hello World
							char * msg = "HTTP/1.1 200 OK\nContent-Type: text/html\n\n<html><body><h1>Hello World<h1></body></html>";
							send(clients[i], msg, strlen(msg), 0);
						}
						else if (strcmp(path, "/test.jpg") == 0)
						{
							char * msg = "HTTP/1.1 200 OK\nContent-Type: image/jpeg\n\n";
							send(clients[i], msg, strlen(msg), 0);

							FILE *f = fopen("D:\\Test\\test.jpg", "rb");
							while (true)
							{
								res = fread(filebuf, 1, sizeof(filebuf), f);
								if (res > 0)
									send(clients[i], filebuf, res, 0);
								else
									break;
							}
							fclose(f);
						}
						else if (strcmp(path, "/test.mp3") == 0)
						{
							char * msg = "HTTP/1.1 200 OK\nContent-Type: audio/mpeg\n\n";
							send(clients[i], msg, strlen(msg), 0);

							FILE *f = fopen("D:\\Test\\test.mp3", "rb");
							while (true)
							{
								res = fread(filebuf, 1, sizeof(filebuf), f);
								if (res > 0)
									send(clients[i], filebuf, res, 0);
								else
									break;
							}
							fclose(f);
						}
					}

					closesocket(clients[i]);
					removeSocket(clients, &numClients, clients[i]);
					i--;
				}
		}
	}

	return 0;
}

