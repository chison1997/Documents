// VD_CompletionRoutine.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "winsock2.h"

SOCKET client;
OVERLAPPED overlapped;
char buf[1024];
WSABUF databuf;
DWORD flags = 0;
DWORD bytesReceived = 0;
int ret;

void CALLBACK CompletionRoutine(DWORD, DWORD, LPOVERLAPPED, DWORD);

int main()
{
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);

	SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(9000);

	bind(listener, (SOCKADDR *)&addr, sizeof(addr));
	listen(listener, 5);

	client = accept(listener, NULL, NULL);

	memset(&overlapped, 0, sizeof(overlapped));

	databuf.buf = buf;
	databuf.len = sizeof(buf);

	ret = WSARecv(client, &databuf, 1, &bytesReceived, &flags, &overlapped, CompletionRoutine);

	while (1)
		SleepEx(WSA_INFINITE, true);

    return 0;
}

void CALLBACK CompletionRoutine(DWORD dwError, DWORD dwBytesReceived, LPOVERLAPPED lpOverlapped, DWORD dwFlags)
{
	if (dwError != 0 || dwBytesReceived == 0)
	{
		closesocket(client);
		return;
	}

	// Xu ly du lieu nhan duoc trong buffer
	buf[dwBytesReceived] = 0;
	printf("%s", buf);

	// Yeu cau nhan du lieu tiep theo
	memset(&overlapped, 0, sizeof(overlapped));
	flags = 0;

	ret = WSARecv(client, &databuf, 1, &bytesReceived, &flags, &overlapped, CompletionRoutine);
	if (ret == SOCKET_ERROR)
	{
		ret = WSAGetLastError();
		if (ret != WSA_IO_PENDING)
		{
			printf("Error: %d", ret);
		}
	}

	return;
}
