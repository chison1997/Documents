// VD_Event.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "winsock2.h"

int main()
{
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);

	SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(9000);

	bind(listener, (SOCKADDR *)&addr, sizeof(addr));
	listen(listener, 5);

	SOCKET client = accept(listener, NULL, NULL);

	OVERLAPPED overlapped;
	memset(&overlapped, 0, sizeof(overlapped));
	WSAEVENT receiveEvent = WSACreateEvent();
	overlapped.hEvent = receiveEvent;

	char buf[1024];
	WSABUF databuf;
	databuf.buf = buf;
	databuf.len = sizeof(buf);

	DWORD bytesReceived = 0;
	DWORD flags = 0;

	int ret;

	while (1)
	{
		ret = WSARecv(client, &databuf, 1, &bytesReceived, &flags, &overlapped, 0);
		if (ret == SOCKET_ERROR)
		{
			ret = WSAGetLastError();
			if (ret == WSA_IO_PENDING)
				printf("Receiving data...\n");
			else 
			{
				printf("Error: %d\n", ret);
				continue;
			}
		}

		ret = WSAWaitForMultipleEvents(1, &receiveEvent, FALSE, WSA_INFINITE, FALSE);
		if (ret == WSA_WAIT_FAILED)
			continue;

		WSAResetEvent(receiveEvent);
		ret = WSAGetOverlappedResult(client, &overlapped, &bytesReceived, FALSE, &flags);

		if (bytesReceived == 0)
			break;

		buf[bytesReceived] = 0;
		printf("%s", buf);
	}

	closesocket(client);
	closesocket(listener);
	WSACleanup();
    return 0;
}

