//Bài 88: Hãy sử dụng vòng lặp for để xuất tất cả các ký tự từ A đến Z

#include <stdio.h>

main()
{
  for(int i=65; i<=90;i++) printf("%c ",i);
  printf("\n");

}
	
