//Bài 91: In tất cả các số nguyên dương lẻ nhỏ hơn 100
#include <stdio.h>

main()
{	
	int i;
  	for(i=1; i<100; i+=2) printf("%d ",i); 
	printf("\n");

}
	
