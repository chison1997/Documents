#include <stdio.h>
#include <stdlib.h>


int A[9][9];
int markRow[9][10]; //markRow[r][v] = 1 nếu v đã xuất hiện hàng r
int markCol[9][10];//markCol[c][v] = 1 nếu v đã xuất hiện hàng c
int markSquare[3][3][10]; //markSquare[R][C][v] = 1 nếu v đã xuất hiện trong hình vuông to [R][C]


//x = 1 đánh dấu v đã được điền vào hàng r, cột c 
void Mark(int r, int c, int v, int x)
{
	markRow[r][v] = x;
	markCol[c][v] = x;
	markSquare[r/3][c/3][v] = x;
}

//đọc dữ liệu từ file
void readData()
{
	FILE* f = fopen("sudoku.txt", "r");
	for(int r = 0; r < 9; r++)
	{
		for(int c = 0; c < 9; c++)
		{
			fscanf(f, "%d", &A[r][c]);
			if (A[r][c] == 0)
				Mark(r, c, A[r][c], 0);
			else
				Mark(r, c, A[r][c], 1);
		}
	}

	fclose(f);
}

//kiểm tra xem liệu có thể điền v vào hàng r, cột c hay không
bool check(int r, int c, int v) 
{
	if (markRow[r][v]) return 0;
	if (markCol[c][v]) return 0;
	if (markSquare[r/3][c/3][v]) return 0;
	return 1;
}

//in kết quả khi giải xong
void print()
{
	printf("printf");
	FILE* f = fopen("sudoku.html", "w");
	printf("OKfileprint");

	fprintf(f, "<!DOCTYPE html> <html><style> table, th, td { border: 1px solid black; border-collapse: collapse;} </style> <head> <title>Sudoku</title> </head> <body> <table style=""width:20%%"">");
  	for(int I = 0; I < 3; I++)
  	{
  		fprintf(f, "<table style=""width:20%%"">\n" );
  		fprintf(f, "<tr>\n");
  		for(int J = 0; J < 3; J++)
  		{
  			fprintf(f, "<td>\n");
  			for(int i = 0; i < 3; i++)
  			{
  				fprintf(f, "\t<table style=""width:100%%"">\n");
  				fprintf(f, "<tr>\n");
  				for(int j = 0; j < 3; j++)
  				{
  					fprintf(f, "\t<th>%d</th>\n", A[3*I + i][3*J + j]);
  				}
  				fprintf(f, "</tr>\n");
  				fprintf(f, "\t</table>\n");
  			}
  			fprintf(f, "</td>\n");
  		}
  		fprintf(f, "</tr>\n");
  		fprintf(f, "</table>\n");
  	}
  	fprintf(f, "</table> </body> </html>");

	fclose(f);
	exit(0);
}




//thử giá trị cho ô ở hàng r, cột c
void TRY(int r, int c)
{
	printf("%d %d\n", r, c);
	if (A[r][c] != 0)
	{
		if (r == 8 && c == 8)
		{
			print();
		}
		else if (c < 8)
		{
			TRY(r, c + 1);
		}
		else
		{
			TRY(r + 1, 0);
		}
	}
	else
	{
		for(int v = 1; v <= 9; v++)
		{
			if (check(r, c, v))
			{
				A[r][c] = v;
				Mark(r, c, v, 1);

				if (r == 8 && c == 8)
				{
					print();
				}
				else if (c < 8)
				{
					TRY(r, c + 1);
				}
				else
				{
					TRY(r + 1, 0);
				}

				Mark(r, c, v, 0);
			}
			
		}
	}
}

int main(int argc, char** argv)
{
	readData();
	TRY(0, 0);
	return 0;
}
